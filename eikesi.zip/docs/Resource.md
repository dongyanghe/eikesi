### 文件路径:
 - [主目录](  ../README.md)
 - [项目主目录](  ../../README.md)

## 文档:
 - [主目录](  ../README.md)
 - [项目主目录](  ../../README.md)
 
# 项目访问路径
    本地：http://127.0.0.1:4200
    在线：http://www.eikesi.com
---

